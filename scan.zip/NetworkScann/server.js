const express = require('express');
const ping = require('ping');
const app = express();
const path = require('path');

const port = 80;

// Middleware для статических файлов
app.use(express.static(path.join(__dirname, 'public')));

app.get('/scan', async (req, res) => {
    const subnet = req.query.subnet;
    if (!subnet) {
        return res.status(400).json({ error: 'Subnet is required' });
    }

    const promises = [];
    for (let i = 1; i <= 255; i++) {
        const ip = `${subnet}.${i}`;
        promises.push(ping.promise.probe(ip).then(result => {
            if (result.alive) {
                return ip;
            }
            return null;
        }));
    }

    const results = await Promise.all(promises);
    const activeIps = results.filter(ip => ip !== null);

    res.json(activeIps);
});

// Запуск сервера на IP 0.0.0.0, чтобы он был доступен в локальной сети
app.listen(port, '192.168.0.140', () => {
    console.log(`Сервер запущен на http://192.168.0.140:${port}`);
});
