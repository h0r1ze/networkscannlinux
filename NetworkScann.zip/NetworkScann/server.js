const express = require('express');
const ping = require('ping');

const app = express();
const port = 3000;

// Middleware to serve static files
app.use(express.static('public'));

// Endpoint to scan the network
app.get('/scan', async (req, res) => {
    const subnet = req.query.subnet;
    if (!subnet) {
        return res.status(400).json({ error: 'Subnet is required' });
    }

    const activeResults = [];
    const promises = [];

    for (let i = 1; i <= 255; i++) {
        const ip = `${subnet}.${i}`;
        promises.push(
            ping.promise.probe(ip).then((response) => {
                if (response.alive) {
                    activeResults.push(ip);
                }
            })
        );
    }

    await Promise.all(promises);
    
    // Возвращаем активные IP-адреса
    res.json(activeResults);
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});

